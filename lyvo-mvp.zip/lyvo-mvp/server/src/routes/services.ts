import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

export default function servicesRouter(prisma: PrismaClient) {
  const r = Router();
  r.get('/', async (_req, res) => {
    try {
      const services = await prisma.service.findMany();
      res.json(services);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  return r;
}