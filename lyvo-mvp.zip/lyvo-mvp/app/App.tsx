import React from 'react';
import RootNav from './src/navigation';

export default function App() {
  return <RootNav />;
}