import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { PrismaClient } from '@prisma/client';

import servicesRouter from './routes/services.js';
import bookingsRouter from './routes/bookings.js';
import paymentsRouter from './routes/payments.js';

const prisma = new PrismaClient();
const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

// Mount routers
app.use('/services', servicesRouter(prisma));
app.use('/bookings', bookingsRouter(prisma));
app.use('/payments', paymentsRouter(prisma));

const PORT = Number(process.env.PORT) || 4000;
app.listen(PORT, () => {
  console.log(`LYVO API running on :${PORT}`);
});